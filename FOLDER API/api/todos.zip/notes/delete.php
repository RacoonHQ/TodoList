<?php
require_once '../config.php';

// Check if data is sent as JSON or form data
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';

if (strpos($contentType, 'application/json') !== false) {
    // JSON input
    $data = json_decode(file_get_contents("php://input"));
} else {
    // Form data input (x-www-form-urlencoded)
    $data = (object) $_POST;
}

if (!isset($data->id)) {
    sendResponse(false, 'Note ID is required');
    exit;
}

$id = $data->id;

try {
    $stmt = $conn->prepare("DELETE FROM notes WHERE id = ?");
    if ($stmt->execute([$id])) {
        sendResponse(true, 'Note deleted successfully');
    } else {
        sendResponse(false, 'Failed to delete note');
    }
} catch(PDOException $e) {
    sendResponse(false, 'Database error: ' . $e->getMessage());
}
?>
